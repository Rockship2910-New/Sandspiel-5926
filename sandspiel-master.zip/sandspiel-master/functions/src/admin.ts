const admins = ["maxbittker@gmail.com"];
export default admins;
