let ratio = 4;
if (window.devicePixelRatio > 1) {
  ratio = 3;
}
export { ratio };
