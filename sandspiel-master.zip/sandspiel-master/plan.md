Nutrients:
Moisture
Sugar
Nitrogen

Substrates:
Dirt
Stone
Water

Plants:
kelp
grass
flower
vine

Fungus:
mycilium
puff-cap

Animals:
worm
ant
snail
shrimps
